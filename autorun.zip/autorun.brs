' Native dual roVideoPlayer controller + Node/HTML widget orchestration.
' Node posts { cmd, url, cb } via @brightsign/messageport PostBSMessage (roNodeJsEvent).

sub main()
  print "=== BrightSign autorun starting ==="

  defaultDrive = GetDefaultDrive() 'bs:disable-line
  print "Default drive: "; defaultDrive

  ' Optional per-install override, absent from the generic release zip. Drop
  ' a server-config.json next to autorun.brs in a customer-specific copy of
  ' the zip to bake in that site's server URL at provisioning time -- lets
  ' one client build serve every customer instead of maintaining a build per
  ' server. Runs before the Node bundle starts so bootstrapSync.js (which
  ' reads this same registry value on every boot) sees it immediately.
  ApplyServerConfigOverride(defaultDrive)

  ok = CreateDirectory(defaultDrive + "brightsign-dumps")
  if not ok then
    print "Could not create "; defaultDrive + "brightsign-dumps"
  end if

  mp = CreateObject("roMessagePort")

  ' Unlocks the BSN.cloud Properties Panel for this device. Custom-script
  ' players are locked out of it by default; this tells the local supervisor
  ' to accept cloud-pushed settings. Async on the shared port `mp` so the
  ' response (a roUrlEvent) is picked up by the main event loop below instead
  ' of a separate blocking loop (BrightSign's own sample code loops forever
  ' waiting on it, which would never let the rest of this sub run).
  ' The returned roUrlTransfer MUST stay referenced: if it is garbage
  ' collected the in-flight POST is cancelled and the supervisor never
  ' registers us (this is why 1.0.20's version never took effect).
  settingsXfer = EnableSettingsHandler(mp)

  print "Starting NodeJS bundle..."

  nodeConfig = CreateObject("roAssociativeArray")
  nodeConfig.message_port = mp

  bundlePath = defaultDrive + "server.bundle.js"
  node = CreateObject("roNodeJs", bundlePath, nodeConfig) 'bs:disable-line

  readyFile = defaultDrive + "abierto/.server-ready"
  if not WaitForReadyFile(readyFile, 30000) then
    print "Server failed to start within 30s - exiting"
    return
  end if

  vidmode = CreateObject("roVideoMode") 'bs:disable-line
  ' HTML widget draws on the graphics plane; put graphics behind video so roVideoPlayer is visible.
  if not vidmode.SetGraphicsZOrder("back") then
    print "SetGraphicsZOrder(back) failed: "; vidmode.GetFailureReason()
  end if

  screenW = vidmode.GetResX()
  screenH = vidmode.GetResY()
  screenRect = CreateObject("roRectangle", 0, 0, screenW, screenH) 'bs:disable-line

  ' HTML first, then native video on top (ToFront) so roVideoPlayer is not covered.
  widget = SafeCreateHTMLWidget(mp, "http://localhost:13131/bootstrap.html")
  if widget = invalid then
    print "Failed to create HTML widget - exiting"
    return
  end if

  print "HTML widget created, loading..."
  widget.Show()

  videoState = CreateNativeVideoState(screenRect, mp)
  if videoState = invalid then
    print "Failed to initialize native video players - exiting"
    return
  end if

  videoState.htmlWidget = widget

  ' Keep the HTML app underneath native video (raise()/hwz puts HTML on top by default).
  widget.Lower()
  videoState.active.ToFront()

  print "=== Entering event loop ==="
  while true
    msg = wait(0, mp)
    if type(msg) = "roNodeJsEvent" then
      HandleNodeJsEvent(msg, videoState)
    else if type(msg) = "roVideoEvent" then
      HandleVideoEvent(msg, videoState)
    else if type(msg) = "roHtmlWidgetEvent" then
      print "HTMLWidgetEvent: "; msg
    else if type(msg) = "roMessagePortEvent" then
      print "MessagePortEvent: "; msg
    else if type(msg) = "roUrlEvent" then
      print "EnableSettingsHandler response code: "; msg.GetResponseCode()
    end if
  end while
end sub

' Reads <sdroot>/server-config.json (flat JSON, e.g. {"server_url": "..."})
' if present and writes its server_url into the registry, overriding
' whatever is already there. Missing file, unreadable JSON, or a missing/
' empty server_url are all silently treated as "no override" -- the device
' falls back to its current registry value (set via setup.html, a prior
' override, or a manual registry write).
sub ApplyServerConfigOverride(defaultDrive as string)
  configPath = defaultDrive + "server-config.json"
  raw = ReadAsciiFile(configPath)
  if raw = invalid or raw = "" then
    print "ApplyServerConfigOverride: no server-config.json found - skipping"
    return
  end if

  config = ParseJson(raw)
  if config = invalid then
    print "ApplyServerConfigOverride: server-config.json is not valid JSON - skipping"
    return
  end if

  serverUrl = config.server_url
  if serverUrl = invalid or serverUrl = "" then
    print "ApplyServerConfigOverride: server-config.json missing server_url - skipping"
    return
  end if

  regSection = CreateObject("roRegistrySection", "abierto") 'bs:disable-line
  regSection.Write("server_url", serverUrl)
  regSection.Flush()
  print "ApplyServerConfigOverride: server_url set from server-config.json: "; serverUrl
end sub

' See https://docs.brightsign.biz partner doc "Applying Settings in the
' Properties Panel". POSTs to the player's own local supervisor (not the
' CMS server) to announce this is a custom script, which unlocks the
' BSN.cloud Properties Panel for the device. Response arrives as a
' roUrlEvent on `mp` and is handled in the main event loop above. Returns
' the roUrlTransfer; the caller must keep it alive until the response lands.
function EnableSettingsHandler(mp as object) as object
  xfer = CreateObject("roUrlTransfer") 'bs:disable-line
  xfer.SetUrl("http://localhost/api/v1/system/supervisor/capabilities")
  xfer.SetTimeout(15000)
  xfer.SetProxyBypass(["127.0.0.1", "localhost"])
  xfer.AddHeader("Content-type", "application/json")
  xfer.SetPort(mp)

  script = CreateObject("roAssociativeArray")
  script.AddReplace("type", "Custom")
  script.AddReplace("version", "1.0.0") ' informational only, shown in BSN.cloud's Settings Panel

  body = CreateObject("roAssociativeArray")
  body.AddReplace("script", script)

  ok = xfer.AsyncPostFromString(FormatJson(body))
  if not ok then
    print "EnableSettingsHandler: failed to send capabilities POST"
  else
    print "EnableSettingsHandler: capabilities POST sent"
  end if

  return xfer
end function

function CreateNativeVideoState(screenRect as object, mp as object) as object
  state = CreateObject("roAssociativeArray")
  state.screenRect = screenRect
  state.messagePort = mp
  state.htmlWidget = invalid
  state.standbyUrl = ""
  state.playCallback = "PlatformInterface.videoPlayed"
  state.playStartedCallback = "PlatformInterface.videoStarted"

  state.playerA = CreateObject("roVideoPlayer") 'bs:disable-line
  state.playerB = CreateObject("roVideoPlayer") 'bs:disable-line

  if state.playerA = invalid or state.playerB = invalid then
    print "CreateNativeVideoState: roVideoPlayer creation failed"
    return invalid
  end if

  ConfigureVideoPlayer(state.playerA, screenRect, mp, "A")
  ConfigureVideoPlayer(state.playerB, screenRect, mp, "B")

  state.active = state.playerA
  state.standby = state.playerB

  print "Native video: dual roVideoPlayer ready"
  return state
end function

sub ConfigureVideoPlayer(player as object, rect as object, mp as object, label as string)
  player.SetRectangle(rect)
  player.SetViewMode("fillscreenandcentered")
  player.SetLoopMode("noloop")
  player.SetPort(mp)
  player.SetUserData(label)
  player.SetOpacity(255)
  player.Hide()
end sub

' Ensure the active player is visible before PlayFile (field logs showed opacity=0, FPS 0).
sub PresentActivePlayer(player as object)
  if player = invalid then return

  player.SetOpacity(255)
  player.Show()
  player.ToFront()
end sub

sub HandleNodeJsEvent(msg as object, state as object)
  data = msg.GetData()
  if data = invalid then return

  if data.reason <> "message" then return

  ' Node PostBSMessage payload is in data.message (see @brightsign/messageport docs).
  payload = data.message
  if payload = invalid then payload = data

  cmd = payload.cmd
  if cmd = invalid or cmd = "" then return

  if cmd = "prepare" then
    PrepareNativeVideo(state, payload.url)
  else if cmd = "play" then
    if payload.cb <> invalid and payload.cb <> "" then
      state.playCallback = payload.cb
    end if
    if payload.startCb <> invalid and payload.startCb <> "" then
      state.playStartedCallback = payload.startCb
    end if
    PlayNativeVideo(state, payload.url)
  else if cmd = "hide" then
    HideNativeVideo(state)
  else
    print "HandleNodeJsEvent: unknown cmd "; cmd
  end if
end sub

sub PrepareNativeVideo(state as object, url as string)
  ' Preload disabled: PreloadFile kept clips paused (FPS 0) on XT2145 in field logs.
  ' Playlist may still call prepare; play uses PlayFile on the active player.
  if url = invalid or url = "" then return
  print "Native video prepare skipped: "; url
end sub

sub PlayNativeVideo(state as object, url as string)
  if url = invalid or url = "" then
    InvokeCallback(state, state.playCallback, "PlatformInterface.videoPlayed")
    return
  end if

  print "Native video play: "; url

  active = state.active
  standby = state.standby
  if active = invalid or standby = invalid then return

  params = CreateObject("roAssociativeArray")
  params.url = url
  params.filename = url
  params.loopmode = "noloop"

  ' Always cold-start on the active player. PreloadFile+swap left clips paused (FPS 0) on XT2145.
  state.standbyUrl = ""
  state.standby.StopClear()
  state.standby.Hide()

  ' Stop(), not StopClear(), on the outgoing clip: per BrightSign's own API docs, StopClear()
  ' "clears the currently loaded file or stream" (blanks the visible frame), while Stop() only
  ' halts playback. Using StopClear() here was wiping the still-visible last frame the instant a
  ' video-to-video transition began, on top of HandleVideoEvent's own premature Hide() on EOF --
  ' together those produced a visible gray flash on every video-to-video cut (QA-reported
  ' 2026-08-24). Stop() leaves the last frame composited until PlayFile() below actually produces
  ' new ones, turning the hide-then-flash into a frozen-frame-then-cut.
  active.Stop()
  PresentActivePlayer(active)

  ok = active.PlayFile(params)
  if not ok then
    print "Native video PlayFile failed for "; url; " reason="; active.GetFailureReason()
    InvokeCallback(state, state.playCallback, "PlatformInterface.videoPlayed")
    return
  end if
end sub

sub HideNativeVideo(state as object)
  print "Native video hide"
  if state.active <> invalid then
    state.active.StopClear()
    state.active.Hide()
  end if
  if state.standby <> invalid then
    state.standby.StopClear()
    state.standby.Hide()
  end if
  state.standbyUrl = ""
end sub

sub HandleVideoEvent(msg as object, state as object)
  status = msg.GetInt()
  playerLabel = ""
  userdata = msg.GetUserData()
  if userdata <> invalid then playerLabel = userdata

  ' roVideoEvent status codes (BrightSign SDK): 3 = Playing (first frame up),
  ' 8 = MediaEnded. Only these two are acted on today.
  if status = 3 then
    print "Native video started (player "; playerLabel; ")"
    InvokeCallback(state, state.playStartedCallback, "PlatformInterface.videoStarted")
    return
  end if

  if status <> 8 then
    print "Native video event status="; status; " player="; playerLabel
    return
  end if

  print "Native video ended (player "; playerLabel; ")"

  ' Deliberately NOT hiding state.active here. HideNativeVideo() (next slide is an image) and
  ' PlayNativeVideo() (next slide is another video) both already manage this player's visibility
  ' correctly on their own -- hiding it here too was eager: it ran before JS even knows what's
  ' next, so a video-to-video transition sat on a hidden/empty player for the full async
  ' round-trip (HTTP to the Node sidecar, BrightScript message port, decoder start) before the
  ' next PlayFile() produced a frame. Leaving the last frame composited here instead means that
  ' round-trip holds a frozen frame, not a gray flash -- see the matching Stop()-not-StopClear()
  ' change in PlayNativeVideo() above (QA-reported 2026-08-24).
  InvokeCallback(state, state.playCallback, "PlatformInterface.videoPlayed")
end sub

sub InvokeCallback(state as object, callback as string, fallback as string)
  widget = state.htmlWidget
  if widget = invalid then return
  if callback = invalid or callback = "" then
    callback = fallback
  end if

  js = "try{var fn=" + callback + ";if(typeof fn==='function'){fn();}else if(" + fallback + "){" + fallback + "();}}catch(e){console.warn('[native-video] callback failed',e);}"
  ok = widget.InjectJavascript(js)
  if not ok then
    print "InjectJavascript failed for callback "; callback
  end if
end sub

function WaitForReadyFile(filePath as string, maxWaitMs as integer) as boolean
  waited = 0
  while waited < maxWaitMs
    if ReadAsciiFile(filePath) <> "" then
      DeleteFile(filePath)
      print "Server ready after "; waited; "ms"
      return true
    end if
    sleep(250)
    waited = waited + 250
  end while
  print "Server not ready after "; maxWaitMs; "ms"
  return false
end function

function SafeCreateHTMLWidget(mp as object, url as string) as object
  vidmode = CreateObject("roVideoMode") 'bs:disable-line
  width = vidmode.GetResX()
  height = vidmode.GetResY()
  r = CreateObject("roRectangle", 0, 0, width, height) 'bs:disable-line
  config = CreateObject("roAssociativeArray")
  ' Native roVideoPlayer handles playlist video; avoid HWZ <video> competing for the decoder.
  config.hwz_default = "off"
  config.javascript_enabled = true
  config.mouse_enabled = true
  inspector = CreateObject("roAssociativeArray")
  inspector.port = 3000
  config.inspector_server = inspector
  config.url = url
  config.port = mp
  for i = 1 to 10
    h = CreateObject("roHtmlWidget", r, config) 'bs:disable-line
    if h <> invalid then
      print "HTML Widget created on try "; i
      return h
    else
      print "HTML Widget creation failed, retry "; i
      sleep(1000)
    end if
  next
  print "Failed to create HTML Widget after 10 tries"
  return invalid
end function